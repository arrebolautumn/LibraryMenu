/**
 * author: Phuong Nguyen
 * day: 8:33 pm 08/07/2022
 *
 * */

package Jumping;

import java.util.ArrayList;

public class Book {
    private String title;
    private static ArrayList<Book> allBook = new ArrayList<>();
    private ArrayList<String> genre= new ArrayList<>();
    private String author;
    private int numberOfAvailable;
    private int series;
    private static int totalNumberOfBook;
    private String content;
    private boolean hold=false;

    Book(){
    }
    Book(String title, String author,String[] genre, int series, int numberOfAvailable) {
        totalNumberOfBook++;
        this.numberOfAvailable=numberOfAvailable;
        this.series=series;
        this.title=title;
        this.author = author;
        for (int i=0;i<genre.length;i++){
            this.genre.add(genre[i]);
        }
        allBook.add(this);
    }
public void setSeries(int series){
        this.series =series;
}
    public String getAuthor() {
        return author;
    }

    public void addGenre(String newGenre){
        this.genre.add(newGenre);

    }

    public ArrayList<String> getGenre() {
        return genre;
    }

    public String getTitle() {
        return title;
    }public String toString(){
        return "#"+this.series+" - "+this.title+" - " +this.author+": "+printGenre();
    }
    public String printGenre(){
        String phrase="";
        for (int i=0;i<genre.size();i++){
            if (genre.get(i)!=null) {
                phrase = phrase + genre.get(i);
            }
            if ((i!=genre.size()-1)/*&&(genre.get(i+1)!=null)*/){
                phrase=phrase+(", ");
            }
        }
        return phrase;
    }

    public static int getTotalNumberOfBook() {
        return totalNumberOfBook;
    }

    public int getSeries() {
        return series;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean isHold(int check) {
        if ((check==1)&&(this.hold)) {
            System.out.println("Please notice the first person who borrow \"" + this.title + "\" to return it as soon as possible because it is on Hold!");
        }
        return hold;
    }
    public void setHold(boolean hold) {
        System.out.println("  -> "+this.title+" has been put on Hold successfully!");
        this.hold = hold;
    }
    public static ArrayList<Book> getAllBook(){
        return Book.allBook;
    }
    public int getNumberOfAvailable() {
        return numberOfAvailable;
    }

    public void setNumberOfAvailable(int numberOfAvailable) {
        this.numberOfAvailable = numberOfAvailable;
    }public static void viewHoldList(){
        boolean holdStatus ;

        int i=0;
        for (Book e: allBook){
            holdStatus=e.isHold(1);
           if (holdStatus){
               i++;
           }
        }if (i==0){
            System.out.println("There is no Hold!");
        }
    }
}
