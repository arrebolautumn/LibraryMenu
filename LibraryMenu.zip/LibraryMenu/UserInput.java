/**
 * author: Phuong Nguyen
 * day: 8:33 pm 08/07/2022
 *
 * */

package Jumping;
import java.util.ArrayList;
public class UserInput {
    private String person;
    private String keyword;
    private ArrayList<String> service= new ArrayList<>();
    private ArrayList<Book> borrowed = new ArrayList<>();
    UserInput(){
    }



    public void addBorrowed(Book book){
       this.borrowed.add(book);
    }

    public void setService(String service) {
        this.service.add(service) ;
    }public ArrayList<String> getService(){
        return this.service;
    }


    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }


    public void setPerson(String person) {
        this.person = person;
    }
}
