/**
 * author: Phuong Nguyen
 * day: 8:33 pm 08/07/2022
 *
 * */

package Jumping;

public class Employee {
    private String name;
    private int ID;
    private String role;
    Employee(){
        this.ID=0;
    }
    Employee(String name, int ID, String role){
        this.ID=ID;
        this.role =role;
        this.name =  name;
    }public String toString(){
        return this.name+" - "+this.ID;
    }

    public int getID() {
        return ID;
    }
    public String getName(){return this.name;}
    public String getRole(){return  this.role;}
}
