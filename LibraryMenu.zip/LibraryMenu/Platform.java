/**
 * author: Phuong Nguyen
 * day: 8:33 pm 08/07/2022
 *
 * */
package Jumping;
import java.util.*;

import com.google.common.collect.ArrayListMultimap;
public class Platform {
    public static ArrayList<Book> cart = new ArrayList<>();
    public static Scanner input = new Scanner (System.in);
    public static void main(String[] args) {
        UserInput mainUserInput = new UserInput();

        ArrayListMultimap<String, Book> library = ArrayListMultimap.create();
        System.out.print("Are you a Customer/Employee of the library? (CUSTOMER/EMPLOYEE): ");
        String answer = input.nextLine().toLowerCase();
        mainUserInput.setPerson(answer.toUpperCase());

        String[] list1 = {"romance", "teen", "splash"};

        Book book1 = new Book("The Possibility of Somewhere", "Julia Day", list1, 8592, 3);
        book1.setContent("""
                Ash Gupta has a life full of possibility. His senior year is going exactly as he’s always wanted-- he's admired by his peers, enjoying his classes and getting the kind of grades that his wealthy, immigrant parents expect. There's only one obstacle in Ash's path: Eden Moore—the senior most likely to become class valedictorian. How could this unpopular, sharp-tongued girl from the wrong side of the tracks stand in his way?

                All Eden's ever wanted was a way out. Her perfect GPA should be enough to guarantee her a free ride to college -- and an exit from her trailer-park existence for good. The last thing she needs is a bitter rivalry with Ash, who wants a prized scholarship for his own selfish reasons. Or so she thinks. . . When Eden ends up working with Ash on a class project, she discovers that the two have more in common than either of them could have imagined. They’re both in pursuit of a dream -- one that feels within reach thanks to their new connection. But what does the future hold for two passionate souls from totally different worlds?""");

        String[] list2 = {"romance", "teen", "fiction"};
        Book book2 = new Book("You've Reached Sam", "Dustin Thao", list2, 9458,4);
        book2.setContent("17-year-old Julie Clarke's life is drastically changed when her boyfriend, Sam, dies " +
                "and she isn't given a chance to say goodbye. Heartbroken and unable to process her grief, Julie " +
                "does everything to erase Sam from her life.9");

        String[] list3 = {"romance", "scientist", "fiction"};
        Book book3 = new Book("The Love Hypothesis", "Ali Hazelwood", list3,9238,5);
        book3.setContent("""
                As a third-year Ph.D. candidate, Olive Smith doesn't believe in lasting romantic relationships--but her best friend does, and that's what got her into this situation. Convincing Anh that Olive is dating and well on her way to a happily ever after was always going to take more than hand-wavy Jedi mind tricks: Scientists require proof. So, like any self-respecting biologist, Olive panics and kisses the first man she sees.

                That man is none other than Adam Carlsen, a young hotshot professor--and well-known ass. Which is why Olive is positively floored when Stanford's reigning lab tyrant agrees to keep her charade a secret and be her fake boyfriend. But when a big science conference goes haywire, putting Olive's career on the Bunsen burner, Adam surprises her again with his unyielding support and even more unyielding... six-pack abs.

                Suddenly their little experiment feels dangerously close to combustion. And Olive discovers that the only thing more complicated than a hypothesis on love is putting her own heart under the microscope.\s""");

        String[] list4 = {"history", "research", "non-fiction"};
        Book book4 = new Book("A People's History of the United States", "Howard Zinn ", list4, 6342,2);
        book4.setContent("Presents the history of the United States from the point of view of those who were " +
                "exploited in the name of American progress.\n");


        String[] list5 = {"economic", "political", "non-fiction"};
        Book book5 = new Book("Why Nations Fail: The Origins of Power, Prosperity, and Poverty", "Daron Acemoglu", list5,2342,2);
        book5.setContent("\n" +
                "“Why Nations Fail” is a sweeping attempt to explain the gut-wrenching poverty that leaves 1.29 " +
                "billion people in the developing world struggling to live on less than $1.25 a day. You might " +
                "expect it to be a bleak, numbing read. It's not. It's bracing, garrulous, wildly ambitious and ultimately hopeful.");


        String[] list6 = {"art", "history", "non-fiction"};
        Book book6 = new Book("The Metropolitan Museum of Art: Masterpiece Paintings", " Thomas Campbell", list6,2644,4);
        book6.setContent("In line with best-selling The Louvre: All the Paintings, and Rizzoli's successful " +
                "The Hermitage Collections and The Barnes Foundation: Masterworks, this title offers an exquisite " +
                "tour, unique in its lavish illustration, scholarship, extent, and graceful packaging. As the " +
                "first large survey published in 30 years, and the first large general survey of the Met's " +
                "paintings collection it is the first to celebrate the greatest and most iconic paintings of one " +
                "of the largest, most important, and most beloved museums in the world. This impressive book’s " +
                "broad sweep of material, all from a single museum, makes it at once a universal history of " +
                "painting and the ideal introduction to the iconic masterworks of this world-renowned institution. " +
                "Lavish color illustrations and details of 500 masterpieces, created over 5,000 years in cultures " +
                "across the globe, are presented chronologically from the dawn of civilization to the present. " +
                "These works represent a grand tour of painting from ancient Egypt and classical antiquity and " +
                "prized Byzantine and medieval altarpieces, to paintings from Asia, India, Africa, and the " +
                "Americas and the greatest European and North American masters");

        String[] list7 = {"economics", "history", "non-fiction"};
        Book book7 = new Book("Poor Economics", "Abhijit Banerjee", list7,5826,0);
        book7.setContent("""
                Why would a man in Morocco who doesn’t have enough to eat buy a television?

                Why is it so hard for children in poor areas to learn even when they attend school?

                Why do the poorest people in the Indian state of Maharashtra spend 7 percent of their food budget on sugar?

                Does having lots of children actually make you poorer?""");

        String[] list8 = {"finance", "economics", "non-fiction"};
        Book book8 = new Book("A Random Walk Down Wall Street: The Time-Tested Strategy for Successful Investing", "Burton Malkiel", list8,2634,2);
        book8.setContent("Whether you’re considering your first 401k contribution, contemplating retirement, or " +
                "anywhere in between, A Random Walk Down Wall Street is the best investment guide money can buy. " +
                "In this new edition, Burton G. Malkiel shares authoritative insights spanning the full range of " +
                "investment opportunities―including valuable new material on cryptocurrencies like bitcoin, and " +
                "“tax-loss harvesting”―to help you chart a calm course through the turbulent waters of today’s financial markets.");

        String[] list9 = {"philosophy", "scientist", "non-fiction"};
        Book book9 = new Book("Critique of Pure Reason", "Immanuel Kant", list9,1234,1);
        book9.setContent("""
                A seminal text of modern philosophy, Immanuel Kant's Critique of Pure Reason (1781) made history by bringing together two opposing schools of thought: rationalism, which grounds all our knowledge in reason, and empiricism, which traces all our knowledge to experience. Published here in a lucid reworking of Max Müller's classic translation, the Critique is a profound investigation into the nature of human reason, establishing its truth, falsities, illusions, and reality.

                For more than seventy years, Penguin has been the leading publisher of classic literature in the English-speaking world. With more than 1,700 titles, Penguin Classics represents a global bookshelf of the best works throughout history and across genres and disciplines. Readers trust the series to provide authoritative texts enhanced by introductions and notes by distinguished scholars and contemporary authors, as well as up-to-date translations by award-winning translators.""");

        library.put("book", book1);
        library.put("book", book2);
        library.put("book", book3);
        library.put("book", book4);
        library.put("book", book5);
        library.put("book", book6);
        library.put("book", book7);
        library.put("book", book8);
        library.put("book", book9);

        Collection<Book> collection = library.get("book");


        if (answer.equals("employee")) {
            System.out.println("\n"+"=".repeat(6)+" AN EMPLOYEE "+"=".repeat(6));
            ArrayListMultimap<String, Employee> employee = ArrayListMultimap.create();

            Employee emp1 = new Employee("Emily Moore",12345678,"Librarians");
            Employee emp2 = new Employee("Elizabeth Homes",87654321,"Administrative Services Managers");
            Employee emp3 = new Employee("Jake Olsen",98765432,"Library Technicians");
            Employee emp4 = new Employee("William Smith",234567890,"Computer Support Specialists");
            Employee emp5 = new Employee("Jeremy Kinder",654378909,"Public Relations Specialists");
            Employee emp6 = new Employee("Moss Milly",76541234,"Janitors");

            employee.put("employee",emp1);
            employee.put("employee",emp2);
            employee.put("employee",emp3);
            employee.put("employee",emp4);
            employee.put("employee",emp5);
            employee.put("employee",emp6);

            Collection<Employee> libraryEmp = employee.get("employee");
            System.out.print("Please enter you employee ID: ");
            int empID = input.nextInt();
            boolean cont=true;
            Employee accessing = new Employee();
            while (cont) {
                for (Employee e : libraryEmp) {
                    if (empID == e.getID()) {
                        accessing = e;
                        cont = false;
                    }
                }
                if (accessing.getID() == 0) {
                    System.out.print("No matching employee information. Please re-enter your ID (input \"0\") to end session): ");
                    empID = input.nextInt();

                }if (empID==0){
                    cont=false;
                    System.out.println("Thank you!");
                    break;
                }
            }
            System.out.println("Hello " + accessing.getName() + "!");
            if (accessing.getID() != 0) {
                boolean conti = true;
                while (conti) {
                    System.out.println("\n" + "=".repeat(6) + " CHOOSING SERVICE " + "=".repeat(6));
                    System.out.println("\nWhat do you want to do today?");
                    System.out.println("\t1. Make a change to a book\n\t2. View List of Books on Hold\n\t3. End session");
                    System.out.print("You want to: ");
                    String choice = input.nextLine().toLowerCase();
                    if (choice.equals("")) {
                        choice = input.nextLine().toLowerCase();
                    }
                    switch (choice) {
                        case "1", "make a change to a book" -> {
                            System.out.println("\n" + "=".repeat(6) + " MAKE A CHANGE TO A BOOK " + "=".repeat(6));

                            changeABook();
                        }
                        case "2", "view list of books on hold" -> {
                            System.out.println("\n" + "=".repeat(6) + " CHECK HOLD SERVICE " + "=".repeat(6));

                            Book.viewHoldList();
                        }
                        case "3","end session"->{
                            System.out.println("\n" + "=".repeat(6) + " THANK YOU ! " + "=".repeat(6));
                            conti=false;
                        }
                    }
                }
            }

        }else  {
            System.out.println("\n"+"=".repeat(6)+" A CUSTOMER "+"=".repeat(6));
            boolean cont = true;

            ArrayList<Book> list= search(collection, mainUserInput, cont);
            System.out.println("\n"+"=".repeat(6)+" CHOOSING SERVICE "+"=".repeat(6));
            cont = true;
            while (cont) {
                System.out.println("\nWhat service do you want to explore today? (enter the number or the service name): ");
                System.out.println("\t1. Search\n\t2. Read content\n\t3. Borrow Book\n\t4. Put books on Hold\n\t5. End Session");
                System.out.print("You want to: ");
                String service = input.nextLine().toLowerCase();
                boolean success = false;
                if (service.equals("search") || (service.equals("1"))) {
                    search(collection, mainUserInput, cont);
                    success=true;
                }
                else if (service.equals("borrow book") || (service.equals("3"))) {
                    System.out.println("\n" + "=".repeat(6) + " BORROW BOOK SERVICE " + "=".repeat(6));
                    mainUserInput.setService("BORROW BOOK");
                    success = yesBorrow(list, mainUserInput);

                }
                else if (service.equals("read content") || (service.equals("2"))) {
                    System.out.println("\n" + "=".repeat(6) + " READ CONTENT SERVICE " + "=".repeat(6));
                    success = readContent();
                    mainUserInput.setService("READ CONTENT");
                }
                else if (service.equals("put books on hold") || (service.equals("4"))) {
                    System.out.println("\n" + "=".repeat(6) + " PUT BOOK ON HOLD SERVICE " + "=".repeat(6));
                    System.out.print("Please enter the name of the book that you want to put on Hold (enter 0 to end choosing book): ");
                    String holdString = input.nextLine().toLowerCase();
                    success=hold(holdString);
                    mainUserInput.setService("PUT BOOK ON HOLD");
                }
                else if (service.equals("end session") || (service.equals("5"))) {
                    System.out.println("\n" + "=".repeat(6) + " THANK YOU ! " + "=".repeat(6));
                    success = true;
                    cont = false;
                }
                if (!success) {
                    System.out.println("  -> Sorry, we couldn't find any matching information!");
                }
            }

        }
    }

    private static void changeABook() {
        System.out.print("Please enter the Series of the book that you want to change: ");
        int changeBook = input.nextInt();
        Book thisBook = new Book();
        for (int i = 0; i < Book.getAllBook().size(); i++) {
            if (changeBook == Book.getAllBook().get(i).getSeries()) {
                thisBook = Book.getAllBook().get(i);
                break;
            }
        }
        boolean cont = true;
        if (Book.getAllBook().contains(thisBook)){
            while (cont) {
                System.out.println("\nWhat do you want to change about \"" + thisBook.getTitle() + "\" book: ");
                System.out.println("\t1. Content\n\t2. Series\n\t3. Genre \n\t4. Number of Available\n\t5. Hold \n\t6. End Session");
                System.out.print("You want to: ");
                String changePart = input.nextLine().toLowerCase();
                if (changePart.equals("")) {
                    changePart = input.nextLine().toLowerCase();
                }
                boolean success = false;
                switch (changePart) {
                    case "1", "content" -> {
                        System.out.println("\n" + "=".repeat(6) + " CHANGE CONTENT " + "=".repeat(6));
                        success = changeContent(thisBook);
                    }
                    case "2", "series" -> {
                        System.out.println("\n" + "=".repeat(6) + " CHANGE SERIES " + "=".repeat(6));
                        success = changeSeries(thisBook);
                    }
                    case "3", "genre" -> {
                        System.out.println("\n" + "=".repeat(6) + " CHANGE GENRE " + "=".repeat(6));
                        success = changeGenre(thisBook);
                    }
                    case "4", "number of available" -> {
                        System.out.println("\n" + "=".repeat(6) + " CHANGE NUMBER OF AVAILABLE " + "=".repeat(6));
                        success = changeNumberOfAvailable(thisBook);
                    }
                    case "5", "hold status" -> {
                        System.out.println("\n" + "=".repeat(6) + " CHANGE HOLD STATUS " + "=".repeat(6));
                        success = changeHold(thisBook);
                    }
                    case "6", "end session" -> {
                        System.out.println("\n" + "=".repeat(6) + " END SESSION " + "=".repeat(6));
                        System.out.println("You are out \"Make a change to a book\"!");
                        cont = false;
                        System.out.println(" ");
                    }
                }
                if (success) {
                    System.out.println("Information about \"" + thisBook.getTitle() + "\" has been changed successfully!");
                }
            }
        }else{
            System.out.println("The book whose series is "+changeBook+" does not exist!");
        }
    }
    public static boolean changeHold(Book thisBook){
        System.out.print("Please enter the new Hold Number of \""+thisBook.getTitle()+"\": ");
        int newNumber= input.nextInt();
        thisBook.setNumberOfAvailable(newNumber);
        return true;
    }
    public static boolean changeNumberOfAvailable(Book thisBook){
        System.out.print("Please enter the new Number of Available of \""+thisBook.getTitle()+"\": ");
        int newNumber= input.nextInt();
        thisBook.setNumberOfAvailable(newNumber);
        return true;

    }
    public static boolean changeGenre(Book thisBook){
        boolean success=false;
        boolean cont=true;
        while (cont) {
            success=false;
            System.out.println("Please choose your service for Genre-changing: ");

            System.out.println("\t1. Add a new genre\n\t2. Delete an incorrect genre\n\t3. End changing Genre");
            System.out.print("You want to: ");
            String choice = input.nextLine().toLowerCase();
            switch (choice) {
                case "1", "add a new genre" -> success = addGenre(thisBook);
                case "2", "delete an incorrect genre" -> success = deleteGenre(thisBook);
                case "3", "end changing genre" -> cont = false;
            }if (success){
                System.out.println("Genre of \""+thisBook.getTitle()+"\" has been modified successfully!");
            }
            System.out.println("");

        }
        return (success);
    }
    private static boolean deleteGenre(Book thisBook){
        boolean success=true;
        System.out.print("Please enter the incorrect Genre of \""+thisBook.getTitle()+"\": ");
        String delete= input.nextLine().toLowerCase();
        if (!thisBook.getGenre().contains(delete)) {
            success=false;
            System.out.println("\""+delete+"\" is not a genre of \""+thisBook.getTitle()+"\" initially.\nDelete unsuccessful!");
        }else{
            thisBook.getGenre().remove(delete);
        }
        return success;
    }
    private static boolean addGenre(Book thisBook){
        System.out.print("Please enter the new Genre of \""+thisBook.getTitle()+"\": ");
        String newGenre= input.nextLine();
        boolean success=true;
        if (thisBook.getGenre().contains(newGenre)) {
            success=false;
            System.out.println("This genre has been included already!");
        }else {
            thisBook.addGenre(newGenre);
        }return success;
    }
    public static boolean changeSeries(Book thisBook){
        System.out.print("Please enter the new Series of \""+thisBook.getTitle()+"\": ");
        int newSeries = input.nextInt();
        boolean success=true;
        for (int i=0;i<Book.getAllBook().size();i++) {
            if (newSeries==Book.getAllBook().get(i).getSeries()){
                success=false;
                System.out.println(Book.getAllBook().get(i).getTitle()+" is named "+ newSeries+" already! Please name it differently!");
            }

        }if (success) {
            thisBook.setSeries(newSeries);
        }

        return (success);
    }
    public static boolean changeContent(Book thisBook){
        System.out.print("Please enter the new content of \""+thisBook.getTitle()+"\": ");
        String newContent = input.nextLine();
        thisBook.setContent(newContent);
        return (thisBook.getContent().equals(newContent));
    }
    public static boolean hold(String holdString) {
        Book onHold;
        boolean success=false;
        for (int i = 0; i < Book.getAllBook().size(); i++) {
            if (holdString.equals(Book.getAllBook().get(i).getTitle().toLowerCase())) {
                onHold = Book.getAllBook().get(i);
                    onHold.setHold(true);
                    success=true;
                    onHold.setNumberOfAvailable(onHold.getNumberOfAvailable()-1);

            }
        }

        return (success);
    }
    public static ArrayList<Book> search(Collection<Book> collection,UserInput mainUserInput, boolean cont){
        ArrayList<Book> list = new ArrayList<>();
        while (cont) {
            System.out.print("Enter the keyword (book's title/ genre): ");
            String bookUser = input.nextLine().toLowerCase();
            mainUserInput.setKeyword(bookUser.toUpperCase());
            list = finding(bookUser, collection);
            //System.out.println("list.size() 2: "+list.size());
            if (!list.isEmpty()) {
                for (int t = 0; t < list.size(); t++) {
                    System.out.println("\t" + (t + 1) + ". " + list.get(t));
                }
                cont=false;
            } else {
                System.out.println("  -> Sorry, we couldn't find any matching information!");
            }
        }
        return list;
    }
    public static boolean readContent() {
        boolean cont = true;
        boolean success=false;
        while (cont) {
            System.out.print("\nEnter the name of the book that you want to read content of (enter 0 to end reading content): ");
            String bookContent =  input.nextLine().toLowerCase();

            for (int i=0;i<Book.getAllBook().size();i++){
                if (bookContent.equals(Book.getAllBook().get(i).getTitle().toLowerCase())) {
                    System.out.println("  -> Content of \"" + Book.getAllBook().get(i).getTitle() + "\": \n" + Book.getAllBook().get(i).getContent());
                    success=true;
                    break;
                }
            }if (bookContent.equals("0")) {
                cont = false;
            }if (!success){
                System.out.println("  -> Sorry, we couldn't find any matching information!");
            }
        }return success;
    }
    public static boolean yesBorrow(ArrayList<Book> list, UserInput mainUserInput){
        Scanner input = new  Scanner(System.in);
        ArrayList<Book> total = Book.getAllBook();
        ArrayList<Book> borrowedBook = new ArrayList<>();
        int except=0;
        int userSeries;
        int range = total.size();
        for (int i=0;i< range;i++){
             except=0;
            System.out.print("Please enter the series of the book (enter 0 to end choosing book): ");
            userSeries = input.nextInt();
            for (int p=0;p<total.size();p++) {
                 if ((userSeries == total.get(p).getSeries())&&(!borrowedBook.contains(total.get(p)))&&(!cart.contains(total.get(p)))) {
                    boolean success =checkNumberOfAvailable(total.get(p));
                    except = 1;
                    if (success) {
                        borrowedBook.add(total.get(p));
                        cart.add(total.get(p));
                        mainUserInput.addBorrowed(total.get(p));
                    }
                }else if ((cart.contains(total.get(p)))&&(total.get(p).getSeries() == userSeries)){
                    except=2;
                }
            }
            if (userSeries==0){
                break;
            }if (except==0) {
                i = i - 1;
                System.out.println("  -> Sorry, we couldn't find any matching information!");
            }else if (except==2){
                System.out.println("  -> You have already borrowed this book!");
            }
        }
        System.out.print(">>> You just added: ");
        if (borrowedBook.size()!=0){
            for (int i=0;i<borrowedBook.size();i++) {
                System.out.print(borrowedBook.get(i).getTitle());
                if (i != borrowedBook.size() - 1) {
                    System.out.print(", ");
                }
            }
        }else{
            System.out.println("empty.");
        }
        System.out.println(" ");
        return true;
    }

    public static boolean checkNumberOfAvailable(Book book) {
        boolean success = true;
        if (book.getNumberOfAvailable()<=0){
            System.out.print("  -> "+book.getTitle()+" is not available now! Do you want to put it on Hold? (YES/NO): ");
            String hold = input.nextLine().toLowerCase();
            success=false;
            if (hold.equals("yes")){
                hold(book.getTitle());
            }
        }else{
            System.out.println("  -> " + book.getTitle() + " is added to the cart!");

        }
        return success;
    }

    public static ArrayList<Book> finding(String userBook, Collection<Book> collection) {
        ArrayList<Book> list = new ArrayList<>();
        userBook =userBook.toLowerCase();
        for (Book e : collection) {
            if (!list.contains(e)) {
                if ((userBook.equals(e.getAuthor().toLowerCase())) || (userBook.equals(e.getTitle().toLowerCase()))) {
                    list.add(e);
                } else {
                    for (int i=0;i<e.getGenre().size();i++){
                        if (userBook.equals(e.getGenre().get(i))){
                            list.add(e);
                        }
                    }
                }
            }
        }
        return list;
    }
}
